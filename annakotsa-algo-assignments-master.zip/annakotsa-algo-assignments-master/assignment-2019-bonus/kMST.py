import turtle
import math

#Για την υλοποίηση του 6ου ερωτήματος χρησιμοποιείται έτοιμη υλοποίηση του αλγορίθμου του Kruskal για την εύρεση MST (βλ. σημείωση στο github)*

class Graph:

    def __init__(self,vertices):
        self.V= vertices #No. of vertices
        self.graph = [] # default dictionary
                                # to store graph


    # function to add an edge to graph
    def addEdge(self,u,v,w):
        self.graph.append([u,v,w])

    # A utility function to find set of an element i
    # (uses path compression technique)
    def find(self, parent, i):
        if parent[i] == i:
            return i
        return self.find(parent, parent[i])

    # A function that does union of two sets of x and y
    # (uses union by rank)
    def union(self, parent, rank, x, y):
        xroot = self.find(parent, x)
        yroot = self.find(parent, y)

        # Attach smaller rank tree under root of
        # high rank tree (Union by Rank)
        if rank[xroot] < rank[yroot]:
            parent[xroot] = yroot
        elif rank[xroot] > rank[yroot]:
            parent[yroot] = xroot

        # If ranks are same, then make one as root
        # and increment its rank by one
        else :
            parent[yroot] = xroot
            rank[xroot] += 1

    # The main function to construct MST using Kruskal's
        # algorithm
    def KruskalMST(self):

        result =[] #This will store the resultant MST

        i = 0 # An index variable, used for sorted edges
        e = 0 # An index variable, used for result[]

            # Step 1:  Sort all the edges in non-decreasing
                # order of their
                # weight.  If we are not allowed to change the
                # given graph, we can create a copy of graph
        self.graph =  sorted(self.graph,key=lambda item: item[2])

        parent = [] ; rank = []

        # Create V subsets with single elements
        for node in range(self.V):
            parent.append(node)
            rank.append(0)

        # Number of edges to be taken is equal to V-1
        while e < self.V -1 :

            # Step 2: Pick the smallest edge and increment
                    # the index for next iteration
            u,v,w =  self.graph[i]
            i = i + 1
            x = self.find(parent, u)
            y = self.find(parent ,v)

            # If including this edge does't cause cycle,
                        # include it in result and increment the index
                        # of result for next edge
            if x != y:
                e = e + 1
                result.append([u,v,w])
                self.union(parent, rank, x, y)
            # Else discard the edge

        # print the contents of result[] to display the built MST
        print "Following are the edges in the constructed MST"
        for u,v,weight  in result:
            #print str(u) + " -- " + str(v) + " == " + str(weight)
            print ("%d -- %d == %d" % (u,v,weight))

def kMST(S, k):

    SC = []
    SC = [0] * k
    SCno = []
    SCno = [[0 for y in xrange(k)] for x in xrange(k)]
    distance = []
    distance = [[0 for y in xrange(k)] for x in xrange(k)]
    q = 0

    for i in S:
      for j in S:
          if i != j:
              #υπολογισμός Ευκλείδειας Απόστασης για si, sj
              distance[i, j] = math.sqrt(sum([(a - b) ** 2 for a, b in zip(i, j)]))
              #χρήση της turtle για την κατασκευή του κύκλου
              centre = distance[i, j] / 2
              turtle.setpos(centre, 0)
              a = math.sqrt(3) * distance[i, j] / 2
              C = turtle.circle(a)
             #προσδιορισμός σημείων που περιέχονται στον κύκλο
              if distance[i, j] <= a:
                  SC[q] = S[i, j]
                  q = q + 1
                  SCno[i, j] = SCno[i, j] + 1

    b = 0
    cell = []
    cell = [0] * k

    #έλεγχος συνθήκης ερωτήματος 2
    for i in S:
      for j in S:
          flag = true
           while (i != j and flag == true and b < k) :
              if SCno[i, j] < k:
                  flag = false
              else:
                  #ερώτημα 3: καθώς το τετράγωνο περιγεγράφει τον κύκλο, η πλευρά του είναι ίση με τη διάμετρο του κύκλου
                  Q = a * 2
                  n = int(math.sqrt(k))
                  #διαίρεση κύκλου σε κελιά
                  cell[b] = Q/math.sqrt(n)
                  b = b + 1

    nu = []
    nu = [0] * k

    for c in range(k):
        nu[c] = 0
        for point in SC:
            if point in cell[c]:
                nu[c] = nu[c] + 1

    #ταξινόμηση κελιών ανάλογα με των αριθμό των σημείων SC που περιέχουν
    for u in range(len(cell)):
        min = u
        for v in range(i+1, len(cell)):
            if nu[min] > nu[v]:
                min = v
        cell[u], cell[min] = cell[min], cell[u]
        nu[u], nu[min] = nu[min], nu[u]

    sum = 0
    node = []
    node = [0] * k

    #choose the minimum number of cells so that the chosen cells together contain at least k points
    for i in range(k):
        while sum < k:
            sum = sum + nu[i]
            node[i] = cell[i]
            #If necessary, arbitrarily discard points from the last chosen cell so that the total number of points in all the cells is equal to k
            if sum > k:
                dif = sum - k
                nu[i] = nu[i] - dif

    KruskalMST(node)
