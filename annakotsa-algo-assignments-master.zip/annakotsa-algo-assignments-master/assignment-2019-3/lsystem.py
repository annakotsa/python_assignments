import math
import json
import sys

import argparse
parser = argparse.ArgumentParser()
parser.add_argument("-m", "--ma", action="store_true")
parser.add_argument('-d', '--da', help = "find grammar", action = "store_true")
parser.add_argument("input_file", nargs='?')
parser.add_argument('output_file', nargs='?')
args = parser.parse_args()

def rotate(pivot, point, angle):
    radians_angle = angle * math.pi / 180
    s = math.sin(radians_angle)
    c = math.cos(radians_angle)
    r_point = [*point]
    # translate to the origin
    r_point[0] -= pivot[0]
    r_point[1] -= pivot[1]
    x_new = r_point[0] * c - r_point[1] * s
    y_new = r_point[0] * s + r_point[1] * c
    # translate back again
    r_point[0] = x_new + pivot[0]
    r_point[1] = y_new + pivot[1]
    return r_point

with open(args.input_file, 'r') as input_file:
    design = json.load(input_file)
    rep = design["order"]
    a = design["axiom"]
    str = design["axiom"]
    gonia = design["start_angle"]
    argon = design["left_angle"]
    degon = design["right_angle"]
    length = design["step_length"]
    kan = design["rules"]


    i = 0
    while i < rep:
        new_string = ""
        for letter in str:
            if letter == "+" or letter == "-" or letter == "[" or letter == "]":
                new_string = new_string + letter
            else:
                if letter in kan:
                    part = kan[letter]
                    new_string = new_string + part
                else:
                    new_string = new_string + letter
        str = new_string
        i = i + 1

if args.ma:
    print(str)

if args.output_file:
    with open(args.output_file, 'w') as output_file:
        point = [0, 0]
        list1 = []
        list2 = []
        left = point
        right = [point[0] + length, point[1]]
        aristera = left
        deksia = right
        pro = point
        for j in new_string:
            if j == "+":
                gonia = gonia + argon
            elif j == "-":
                gonia = gonia - degon
            elif j <= "L":
                point = rotate(left, right, gonia)
                deksia = round(point[0], 2), round(point[1], 2)
                left = point
                aristera = round(pro[0], 2), round(pro[1], 2)
                right = [point[0] + length, point[1]]
                pro = point
                output_file.write("{} {}\n" .format(aristera, deksia))
            elif j == "[":
                list1.append(point)
                list2.append(gonia)
            elif j == "]":
                    pro = list1.pop()
                    gonia = list2.pop()
                    left = pro
                    right = [left[0] + length, left[1]]
            else:
                c = 3
